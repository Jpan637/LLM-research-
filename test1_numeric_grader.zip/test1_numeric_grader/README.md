# Test 1: Fine-tuned vs original Llama 3.1 8B on integration by parts (number-based grader)

This test compares a QLoRA fine-tuned Llama 3.1 8B Instruct
([`Jpan637/llama31-integration-by-parts-lora`](https://huggingface.co/Jpan637/llama31-integration-by-parts-lora))
with the original model on 40 integration-by-parts problems. Every final answer is graded automatically.

![Results summary](results/results_summary.png)

## Results (Oct 25, 2026, Colab T4)

| Test set | Fine-tuned | Original |
|---|---|---|
| Held-out (20) | 65% | 40% |
| Unseen (20) | 70% | 40% |
| **Overall (40)** | **68% (27/40)** | **40% (16/40)** |

- **Head-to-head:** only fine-tuned correct 13, only original correct 2, both correct 14, both wrong 11. Sign test p = 0.007.
- **Step-by-step format:** fine-tuned 95–100%, original 0%.
- **Weakest areas:** substitution-first problems (0% for both) and logarithm problems (fine-tuned 71% vs original 86%).

## Test sets

- **Held-out:** 20 problems from `integration_by_parts_200_verified_fixed_v2.json` kept out of training
  (`train_test_split(test_size=20, seed=3407)`).
- **Unseen:** 20 new integrals that are not in the dataset (listed in the notebook).

## How grading works (`grader_numeric.py`)

1. The final answer is taken from the model's output (the expression after `Final Answer:`, or the last equation if there isn't one).
2. **Indefinite integrals:** the derivative of the answer (central differences) must equal the integrand at six points in (0, 1).
3. **Definite integrals:** the answer must match a Simpson's-rule numerical integral.
4. Equivalent forms count as correct. Only the final answer is graded, not the individual steps.

The grader classifies all 200 reference solutions in the dataset as correct:

```bash
python grader_numeric.py integration_by_parts_200_verified_fixed_v2.json
# 200/200 reference answers graded correct
```

## Reproduce

1. Open `evaluate_numeric_grader.ipynb` in Google Colab and set **Runtime → Change runtime type → T4 GPU**.
2. Upload `integration_by_parts_200_verified_fixed_v2.json` to `/content/`.
3. Run the cells in order. The notebook asks for a Hugging Face token at login. Don't hard-code it.

Settings used: greedy decoding (`do_sample=False`), up to 2,500 new tokens, batch size 4 (about 96 minutes in total).
The original model is the same network with the LoRA adapters disabled (`model.disable_adapter()`), so both models
get identical prompts and settings.

## Files

| File | What it is |
|---|---|
| `evaluate_numeric_grader.ipynb` | Colab notebook: install, load the model, grade, compare |
| `grader_numeric.py` | The number-based grader, with a self-test (`python grader_numeric.py <dataset.json>`) |
| `results/results_summary.png` | One-page results summary |
