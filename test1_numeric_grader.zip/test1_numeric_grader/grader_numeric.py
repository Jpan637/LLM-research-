"""Number-based grader for integration-by-parts answers (test 1).

Indefinite integrals: the derivative of the model's final answer must equal the integrand
at several test points (central differences). Definite integrals: the value must match a
Simpson's-rule numerical integral. Equivalent forms count as correct.
"""
import math, re

# ---------- a tiny LaTeX -> number evaluator ----------
_FUN = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "sec": lambda t: 1 / math.cos(t), "csc": lambda t: 1 / math.sin(t), "cot": lambda t: 1 / math.tan(t),
    "arcsin": math.asin, "arccos": math.acos, "arctan": math.atan,
    "sinh": math.sinh, "cosh": math.cosh, "tanh": math.tanh,
    "ln": math.log, "log": math.log, "exp": math.exp,
}

def _tokens(s):
    s = re.sub(r"\\operatorname\{(\w+)\}", r"\\\1", s)
    for a, b in [("\\left", ""), ("\\right", ""), ("\\,", " "), ("\\;", " "), ("\\!", ""), ("\\cdot", "*"),
                 ("\\times", "*"), ("\\dfrac", "\\frac"), ("\\tfrac", "\\frac"), ("\\big", ""), ("\\Big", ""),
                 ("[", "("), ("]", ")")]:
        s = s.replace(a, b)
    out, i = [], 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1; continue
        if c == "\\":
            m = re.match(r"\\([a-zA-Z]+)", s[i:])
            if not m: i += 1; continue
            out.append("\\" + m.group(1)); i += len(m.group(0)); continue
        m = re.match(r"\d+(\.\d+)?|\.\d+", s[i:])
        if m:
            out.append(float(m.group(0))); i += len(m.group(0)); continue
        out.append(c); i += 1
    return out

class _P:
    def __init__(s, t, x): s.t, s.i, s.x = t, 0, x
    def pk(s): return s.t[s.i] if s.i < len(s.t) else None
    def nx(s): v = s.t[s.i]; s.i += 1; return v
    def expr(s):
        sign = 1
        while s.pk() in ("+", "-"):
            if s.nx() == "-": sign = -sign
        v = sign * s.term()
        while s.pk() in ("+", "-"):
            o = s.nx(); t = s.term(); v = v + t if o == "+" else v - t
        return v
    def term(s):
        v = s.unary()
        while True:
            p = s.pk()
            if p is None or p in ("+", "-", ")", "}", "|"): return v
            if p == "*": s.nx(); v *= s.unary(); continue
            if p == "/": s.nx(); v /= s.unary(); continue
            v *= s.unary()
    def unary(s):
        if s.pk() == "-": s.nx(); return -s.unary()
        return s.power()
    def group(s):
        if s.pk() != "{": return s.atom()
        s.nx(); v = s.expr(); assert s.nx() == "}"; return v
    def power(s):
        v = s.atom()
        while s.pk() == "^":
            s.nx(); e = s.group() if s.pk() == "{" else s.atom(); v = v ** e
        return v
    def atom(s):
        c = s.nx()
        if isinstance(c, float): return c
        if c == "x": return s.x
        if c == "e": return math.e
        if c in ("(", "{"):
            v = s.expr(); assert s.nx() in (")", "}"); return v
        if c == "|":
            v = s.expr(); assert s.nx() == "|"; return abs(v)
        if c == "\\pi": return math.pi
        if c == "\\frac": a = s.group(); b = s.group(); return a / b
        if c == "\\sqrt":
            if s.pk() == "(":  # \sqrt[n]{...} (brackets were turned into parentheses)
                s.nx(); n = s.expr(); s.nx(); return s.group() ** (1 / n)
            return math.sqrt(s.group())
        if c[1:] in _FUN:
            f, pw = _FUN[c[1:]], 1
            if s.pk() == "^": s.nx(); pw = s.group()
            arg = s.atom() if s.pk() in ("(", "{", "|") else s.power()
            return f(arg) ** pw
        raise ValueError("unknown token %r" % (c,))

def evaluate(src, x):
    p = _P(_tokens(src), x)
    v = p.expr()
    if p.i != len(p.t): raise ValueError("leftover tokens")
    return v

# ---------- pulling the pieces out of the question and the answer ----------
def parse_question(q):
    """Returns (integrand_latex, lower, upper) with lower/upper None for indefinite integrals."""
    def braced(s, i):  # returns (contents, index after the closing brace)
        depth = 0
        for j in range(i, len(s)):
            depth += {"{": 1, "}": -1}.get(s[j], 0)
            if depth == 0: return s[i + 1:j], j + 1
    i = q.index("\\int") + 4
    lo = hi = None
    if q[i:i + 2] == "_{":
        lo, i = braced(q, i + 1)
        hi, i = braced(q, i + 1)
    f = q[i:q.index("\\,dx", i)]
    if lo is None: return f, None, None
    return f, evaluate(lo, 0), evaluate(hi, 0)

def extract_answer(text):
    """The model's final expression: right-hand side of the last equation, without '+ C'."""
    part = text.split("Final Answer:")[-1] if "Final Answer:" in text else text
    maths = re.findall(r"\$\$(.+?)\$\$|\\\[(.+?)\\\]|\$(.+?)\$", part, re.S)
    maths = [next(g for g in m if g) for m in maths]
    if not maths: return None
    cand = [m for m in maths if "=" in m] or maths
    expr = cand[-1].split("\\approx")[0].split("=")[-1]
    expr = re.sub(r"\+\s*C\s*$", "", expr.strip().rstrip(".,").strip())
    return expr.strip()

# ---------- grading ----------
def _simpson(f, a, b, n=2000):
    h = (b - a) / n
    return h / 3 * (f(a) + f(b) + sum((4 if k % 2 else 2) * f(a + k * h) for k in range(1, n)))

def grade(question, model_output, points=(0.15, 0.3, 0.45, 0.6, 0.75, 0.9)):
    """True if the answer is mathematically correct. Indefinite: derivative of the answer
    must equal the integrand. Definite: value must match a numerical integral."""
    try:
        f, lo, hi = parse_question(question)
        ans = extract_answer(model_output)
        if ans is None: return False
        if lo is None:
            h, checked = 1e-5, 0
            for x in points:
                try:
                    t = evaluate(f, x)
                except (ValueError, ZeroDivisionError):
                    continue  # integrand undefined here (e.g. arcsin(2x) at x = 0.9)
                d = (evaluate(ans, x + h) - evaluate(ans, x - h)) / (2 * h)
                if abs(d - t) > 1e-4 * max(1, abs(t)): return False
                checked += 1
            return checked >= 3
        true = _simpson(lambda x: evaluate(f, x), lo, hi)
        return abs(evaluate(ans, 0) - true) < 1e-4 * max(1, abs(true))
    except Exception:
        return False

def format_ok(model_output):
    return bool(re.search(r"^Step 1:", model_output.strip())) and "Final Answer:" in model_output


if __name__ == "__main__":
    # Self-test: every reference solution in the dataset should be graded correct.
    import json, sys
    path = sys.argv[1] if len(sys.argv) > 1 else "integration_by_parts_200_verified_fixed_v2.json"
    data = json.load(open(path))
    fails = [i for i, p in enumerate(data) if not grade(p["instruction"], p["output"])]
    print(f"{len(data) - len(fails)}/{len(data)} reference answers graded correct")
    for i in fails:
        print(i, data[i]["instruction"][:90], "|", extract_answer(data[i]["output"]))
