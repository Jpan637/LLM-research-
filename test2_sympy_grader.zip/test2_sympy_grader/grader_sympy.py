"""SymPy grader for integration-by-parts answers (test 2).

Indefinite integrals: SymPy checks that d/dx(answer) - integrand is 0, first numerically at
six points, then tries an exact symbolic proof (3-second limit). Definite integrals: the value
must match an mpmath numerical integral. LaTeX is cleaned before parsing (pi, |...|, implicit
multiplication, function arguments). If SymPy can't read an answer, a number-based backup grader
decides ("fallback"); if SymPy says wrong but the backup confirms the answer, it is counted
correct and flagged ("disputed"). Requires: sympy, mpmath, antlr4-python3-runtime==4.11.
"""
import math, re, signal, mpmath
import sympy as sp
from sympy.parsing.latex import parse_latex

X = sp.Symbol("x")

class _Timeout(BaseException): pass
def _on_alarm(signum, frame): raise _Timeout()
signal.signal(signal.SIGALRM, _on_alarm)

# ---------- reading LaTeX into SymPy ----------
_FN = r"\\(?:arcsin|arccos|arctan|sinh|cosh|tanh|sin|cos|tan|sec|csc|cot|ln|log)(?![a-zA-Z])(?:\^\{[^{}]*\})?"
_FN_END = re.compile(r"\\(?:arcsin|arccos|arctan|sinh|cosh|tanh|sin|cos|tan|sec|csc|cot|ln|log)$")
def _times_after_power(m):
    before = m.string[:m.start()]
    if _FN_END.search(before):          # \ln^{2}(x): a function power, leave it alone
        return m.group(0)
    return m.group(1) + r" \cdot " + m.group(2)
def clean_latex(tex):
    for a, b in [(r"\,", " "), (r"\;", " "), (r"\!", ""), (r"\dfrac", r"\frac"), (r"\tfrac", r"\frac")]:
        tex = tex.replace(a, b)
    # absolute-value bars -> parentheses (d/dx ln|u| = d/dx ln(u) = u'/u, so the derivative check is unchanged)
    tex = tex.replace(r"\left|", r"\left(").replace(r"\right|", r"\right)")
    out, opened = [], False
    for ch in tex:
        if ch == "|":
            out.append(")" if opened else "("); opened = not opened
        else:
            out.append(ch)
    tex = "".join(out)
    # give functions explicit parentheses: \cos x e^{x} -> \cos(x) e^{x}, \ln 2 -> \ln(2), \ln^{2} x -> \ln^{2}(x)
    tex = re.sub(r"(" + _FN + r")\s*(\d+(?:\.\d+)?|\\pi(?![a-zA-Z])|[a-zA-Z](?![a-zA-Z]))", r"\1(\2)", tex)
    # a lone letter or \pi right before "(" is read as a function call, e.g. x(ln x - 1): make it multiplication
    tex = re.sub(r"(\\pi|(?<![a-zA-Z\\])[a-zA-Z])\s*(\\left\(|\()", r"\1 \\cdot \2", tex)
    # a power right before "(" (x^{2}(...), e^{x}(...)) is also made explicit multiplication
    tex = re.sub(r"(\^\{[^{}]*\})\s*(\\left\(|\()", _times_after_power, tex)
    return tex

def to_sympy(tex):
    expr = parse_latex(clean_latex(tex))
    return expr.subs({sp.Symbol("e"): sp.E, sp.Symbol("pi"): sp.pi})   # make e and pi the real constants

def question_parts(q):
    def braced(s, i):
        depth = 0
        for j in range(i, len(s)):
            depth += {"{": 1, "}": -1}.get(s[j], 0)
            if depth == 0: return s[i + 1:j], j + 1
    i = q.index(r"\int") + 4
    lo = hi = None
    if q[i:i + 2] == "_{":
        lo, i = braced(q, i + 1)
        hi, i = braced(q, i + 1)
    return q[i:q.index(r"\,dx", i)], lo, hi

def extract_answer(text):
    part = text.split("Final Answer:")[-1] if "Final Answer:" in text else text
    maths = re.findall(r"\$\$(.+?)\$\$|\\\[(.+?)\\\]|\$(.+?)\$", part, re.S)
    maths = [next(g for g in m if g) for m in maths]
    if not maths: return None
    cand = [m for m in maths if "=" in m] or maths
    expr = cand[-1].split(r"\approx")[0].split("=")[-1]
    return re.sub(r"\+\s*C\s*$", "", expr.strip().rstrip(".,").strip()).strip()

# ---------- backup: the original number-based grader (used only if SymPy can't read an answer) ----------
_FUN = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "sec": lambda t: 1 / math.cos(t), "csc": lambda t: 1 / math.sin(t), "cot": lambda t: 1 / math.tan(t),
    "arcsin": math.asin, "arccos": math.acos, "arctan": math.atan,
    "sinh": math.sinh, "cosh": math.cosh, "tanh": math.tanh,
    "ln": math.log, "log": math.log, "exp": math.exp,
}

def _tokens(s):
    s = re.sub(r"\\operatorname\{(\w+)\}", r"\\\1", s)
    for a, b in [("\\left", ""), ("\\right", ""), ("\\,", " "), (r"\;", " "), ("\\!", ""), ("\\cdot", "*"),
                 ("\\times", "*"), ("\\dfrac", "\\frac"), ("\\tfrac", "\\frac"), ("\\big", ""), ("\\Big", ""),
                 ("[", "("), ("]", ")")]:
        s = s.replace(a, b)
    out, i = [], 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1; continue
        if c == "\\":
            m = re.match(r"\\([a-zA-Z]+)", s[i:])
            if not m: i += 1; continue
            out.append("\\" + m.group(1)); i += len(m.group(0)); continue
        m = re.match(r"\d+(\.\d+)?|\.\d+", s[i:])
        if m:
            out.append(float(m.group(0))); i += len(m.group(0)); continue
        out.append(c); i += 1
    return out

class _P:
    def __init__(s, t, x): s.t, s.i, s.x = t, 0, x
    def pk(s): return s.t[s.i] if s.i < len(s.t) else None
    def nx(s): v = s.t[s.i]; s.i += 1; return v
    def expr(s):
        sign = 1
        while s.pk() in ("+", "-"):
            if s.nx() == "-": sign = -sign
        v = sign * s.term()
        while s.pk() in ("+", "-"):
            o = s.nx(); t = s.term(); v = v + t if o == "+" else v - t
        return v
    def term(s):
        v = s.unary()
        while True:
            p = s.pk()
            if p is None or p in ("+", "-", ")", "}", "|"): return v
            if p == "*": s.nx(); v *= s.unary(); continue
            if p == "/": s.nx(); v /= s.unary(); continue
            v *= s.unary()
    def unary(s):
        if s.pk() == "-": s.nx(); return -s.unary()
        return s.power()
    def group(s):
        if s.pk() != "{": return s.atom()
        s.nx(); v = s.expr(); assert s.nx() == "}"; return v
    def power(s):
        v = s.atom()
        while s.pk() == "^":
            s.nx(); e = s.group() if s.pk() == "{" else s.atom(); v = v ** e
        return v
    def atom(s):
        c = s.nx()
        if isinstance(c, float): return c
        if c == "x": return s.x
        if c == "e": return math.e
        if c in ("(", "{"):
            v = s.expr(); assert s.nx() in (")", "}"); return v
        if c == "|":
            v = s.expr(); assert s.nx() == "|"; return abs(v)
        if c == "\\pi": return math.pi
        if c == "\\frac": a = s.group(); b = s.group(); return a / b
        if c == "\\sqrt":
            if s.pk() == "(":  # \sqrt[n]{...} (brackets were turned into parentheses)
                s.nx(); n = s.expr(); s.nx(); return s.group() ** (1 / n)
            return math.sqrt(s.group())
        if c[1:] in _FUN:
            f, pw = _FUN[c[1:]], 1
            if s.pk() == "^": s.nx(); pw = s.group()
            arg = s.atom() if s.pk() in ("(", "{", "|") else s.power()
            return f(arg) ** pw
        raise ValueError("unknown token %r" % (c,))

def evaluate(src, x):
    p = _P(_tokens(src), x)
    v = p.expr()
    if p.i != len(p.t): raise ValueError("leftover tokens")
    return v


def grade_numeric(question, model_output, points = (0.15, 0.3, 0.45, 0.6, 0.75, 0.9)):
    try:
        f_tex, lo_tex, hi_tex = question_parts(question)
        ans = extract_answer(model_output)
        if ans is None: return False
        if lo_tex is None:
            h, checked = 1e-5, 0
            for x in points:
                try:
                    t = evaluate(f_tex, x)
                except (ValueError, ZeroDivisionError):
                    continue
                d = (evaluate(ans, x + h) - evaluate(ans, x - h)) / (2 * h)
                if abs(d - t) > 1e-4 * max(1, abs(t)): return False
                checked += 1
            return checked >= 3
        lo, hi = evaluate(lo_tex, 0), evaluate(hi_tex, 0)
        n = 2000; step = (hi - lo) / n
        g = lambda x: evaluate(f_tex, x)
        true = step / 3 * (g(lo) + g(hi) + sum((4 if k % 2 else 2) * g(lo + k * step) for k in range(1, n)))
        return abs(evaluate(ans, 0) - true) < 1e-4 * max(1, abs(true))
    except Exception:
        return False

# ---------- the SymPy grader ----------
def _proved(gap, seconds = 3):
    signal.alarm(seconds)
    try:
        return sp.simplify(gap) == 0
    except _Timeout:
        return False
    finally:
        signal.alarm(0)

def _sympy_verdict(question, ans_tex):
    """('symbolic' | 'numeric' | 'wrong'), or raises if SymPy can't read or evaluate the answer."""
    f_tex, lo_tex, hi_tex = question_parts(question)
    f, F = to_sympy(f_tex), to_sympy(ans_tex)
    if lo_tex is None:
        gap = sp.diff(F, X) - f
        checked = 0
        for p in (0.15, 0.3, 0.45, 0.6, 0.75, 0.9):
            fv = complex(f.subs(X, p).evalf())
            if abs(fv.imag) > 1e-12 or not math.isfinite(fv.real): continue
            gv = complex(gap.subs(X, p).evalf())
            if abs(gv) > 1e-8 * max(1, abs(fv)): return "wrong"
            checked += 1
        if checked < 3: raise ValueError("too few usable test points")
        return "symbolic" if _proved(gap) else "numeric"
    a, b = float(to_sympy(lo_tex).evalf()), float(to_sympy(hi_tex).evalf())
    true = complex(mpmath.quad(sp.lambdify(X, f, "mpmath"), [a, b]))
    return "numeric" if abs(complex(F.evalf(20)) - true) < 1e-6 * max(1, abs(true)) else "wrong"

def grade_sympy(question, model_output, return_method = False):
    """True/False. With return_method=True also says how it was decided:
    symbolic = proved exactly by SymPy, numeric = SymPy matched it numerically,
    wrong = SymPy and the backup grader both say incorrect,
    disputed = SymPy said wrong but the backup grader showed it is right (a SymPy misread), fallback = SymPy couldn't read it so the backup grader decided,
    no answer = no final answer found."""
    ans = extract_answer(model_output)
    if ans is None:
        return (False, "no answer") if return_method else False
    try:
        how = _sympy_verdict(question, ans)
        ok = how != "wrong"
        if not ok and grade_numeric(question, model_output):
            # SymPy says wrong but the derivative matches numerically at every test point:
            # that means SymPy misread the LaTeX, so count it as correct and flag it
            ok, how = True, "disputed"
    except (_Timeout, Exception):
        ok, how = grade_numeric(question, model_output), "fallback"
    return (ok, how) if return_method else ok

def format_ok(model_output):
    return bool(re.search(r"^Step 1:", model_output.strip())) and "Final Answer:" in model_output



if __name__ == "__main__":
    # Self-test: every reference solution in the dataset should be graded correct.
    import json, sys
    from collections import Counter
    path = sys.argv[1] if len(sys.argv) > 1 else "integration_by_parts_200_verified_fixed_v2.json"
    data = json.load(open(path))
    fails, methods = [], Counter()
    for i, p in enumerate(data):
        ok, how = grade_sympy(p["instruction"], p["output"], return_method = True)
        methods[how] += 1
        if not ok: fails.append((i, how))
    print(f"{len(data) - len(fails)}/{len(data)} reference answers graded correct")
    print("How they were decided:", dict(methods))
    for i, how in fails:
        print(i, how, "|", data[i]["instruction"][:80], "|", extract_answer(data[i]["output"]))
