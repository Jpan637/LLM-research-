# Test 2: Fine-tuned vs original Llama 3.1 8B on integration by parts (SymPy grader)

This is a re-run of [test 1](../test1_numeric_grader) on the same 40 problems, with every answer graded by **SymPy**.
The report covers both models side by side, problem by problem.

![Results summary](results/results_summary.png)

## Results (Nov 15, 2026, Colab T4)

| Test set | Fine-tuned | Original |
|---|---|---|
| Held-out (20) | 65% | 40% |
| Unseen (20) | 75% | 40% |
| **Overall (40)** | **70% (28/40)** | **40% (16/40)** |

- **Head-to-head:** only fine-tuned correct 14, only original correct 2, both correct 14, both wrong 10. Sign test **p = 0.004**.
- **By problem type:** cyclic 75% vs 0%, definite 70% vs 30%, poly × trig 88% vs 38%, poly × exp 80% vs 60%,
  inverse trig 50% vs 25%, logarithm 71% vs 86%, substitution first 0% vs 0%.
- **Grader agreement:** SymPy agreed with the test 1 number-based grader on **100%** of the 80 answers.
- Full printed report: [`results/colab_output.txt`](results/colab_output.txt).

The one-problem difference from test 1 (poly × trig 75% → 88%) comes from generation at batch size 8 instead of 4,
not from the grader.

## How grading works (`grader_sympy.py`)

1. **Clean the LaTeX** so SymPy's parser reads it correctly:
   - `\pi` and `e` become the real constants.
   - `|…|` becomes `(…)`. For the derivative check, d/dx ln|u| = u′/u either way.
   - Functions get explicit arguments: `\cos x e^{x}` becomes `\cos(x) e^{x}`.
   - `x(…)` and `x^{2}(…)` become multiplication, not function calls.
2. **Indefinite integrals:** compute d/dx(answer) − integrand.
   - It must be 0 at six test points (numeric check).
   - SymPy then tries an exact proof with `simplify` (3-second limit).
   - The result is recorded as **symbolic** (proved exactly) or **numeric** (matched at every point).
3. **Definite integrals:** compare with an `mpmath` numerical integral.
4. **Safety nets:**
   - **fallback:** SymPy can't parse the answer, so the backup number-based grader decides.
   - **disputed:** SymPy says wrong but the backup confirms the answer at every point. This is treated as a SymPy misread and counted correct.

Self-test on the 200 reference solutions: **200/200** (152 symbolic, 47 numeric, 1 disputed).

```bash
pip install sympy mpmath antlr4-python3-runtime==4.11
python grader_sympy.py integration_by_parts_200_verified_fixed_v2.json
```

## Reproduce

1. Open `evaluate_sympy_grader.ipynb` in Google Colab and set **Runtime → Change runtime type → T4 GPU**.
2. Upload `integration_by_parts_200_verified_fixed_v2.json` to `/content/`.
3. Run the cells in order. Log in with a Hugging Face token when asked. Don't hard-code it.

Settings used: greedy decoding, up to 2,500 new tokens, batch size 8 (about 32 minutes in total).

Progress is saved to Google Drive (`MyDrive/ibp_eval/progress.jsonl`) after every batch, so a disconnected run resumes
where it stopped. Delete that file to start a fresh run. The full results, including every model output, are written
to `MyDrive/ibp_eval/eval_results_sympy.csv`.

## Report sections

1. Accuracy by test set
2. Problem-by-problem ✓/✗ for both models
3. Head-to-head counts and sign-test p-value
4. Accuracy by problem type
5. Step-by-step format rate and average length
6. Grader check: how each answer was graded, and agreement with the number-based grader

## Files

| File | What it is |
|---|---|
| `evaluate_sympy_grader.ipynb` | Colab notebook: install, load the model, grader self-test, compare, report |
| `grader_sympy.py` | The SymPy grader with backup, plus a self-test (`python grader_sympy.py <dataset.json>`) |
| `results/results_summary.png` | One-page results summary |
| `results/colab_output.txt` | The full report printed by the notebook |
